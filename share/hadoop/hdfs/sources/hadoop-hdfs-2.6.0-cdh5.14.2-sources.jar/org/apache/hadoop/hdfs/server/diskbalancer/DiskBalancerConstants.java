/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with this
 * work for additional information regarding copyright ownership.  The ASF
 * licenses this file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p/>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p/>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.apache.hadoop.hdfs.server.diskbalancer;

import org.apache.hadoop.classification.InterfaceAudience;
import org.apache.hadoop.classification.InterfaceStability;

/**
 * Constants used by Disk Balancer.
 */
@InterfaceAudience.Private
@InterfaceStability.Unstable
public final class DiskBalancerConstants {
  public static final String DISKBALANCER_BANDWIDTH = "DiskBalancerBandwidth";
  public static final String DISKBALANCER_VOLUME_NAME =
      "DiskBalancerVolumeName";

  /** Min and Max Plan file versions that we know of. **/
  public static final int DISKBALANCER_MIN_VERSION = 1;
  public static final int DISKBALANCER_MAX_VERSION = 1;

  /**
   * We treat a plan as stale if it was generated before the hours
   * defined by the constant below. Defaults to 24 hours.
   */
  public static final int DISKBALANCER_VALID_PLAN_HOURS = 24;
  // never constructed.
  private DiskBalancerConstants() {
  }
}
